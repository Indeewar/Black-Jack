//DATA

// The array "suits" shows the suits in the card pack
let suits = ["Hearts","Diamonds","Club","Spades"];
// The array "cards" shows the suits in the card pack
let cards = ["A","2","3","4","5","6","7","8","9","10","J","Q","K"];
// The array "deck" is created the new array using suits and cards values
let deck =[];
// The array "shuffle_deck" is created after shuffling the deck"
let shuffle_deck = [];
// The array "player_dealt_cards" is created for player dealt cards"
let player_dealt_cards = [];
// The array "computerr_dealt_cards" is created for computer dealt cards"
let computer_dealt_cards = [];
// The global variable "total_card_count" stores the total card count
let total_card_count = 0;
// The global variable "player_dealt_card_count" stores the dealt card count
let player_dealt_card_count = 0;
// The global variable "computer_dealt_card_count" stores the computer card count
let computer_dealt_card_count = 0;
// The global variable "player_score" stores the player score
let player_score = 0;
// The global variable "computer_score" stores the computer score
let computer_score = 0;



//ABSTRACTION

//create the deck using corresponding suits and cards
function card_deck(suits,cards){
    for(let i=0; i<suits.length; i++){
        for(let j=0; j<cards.length; j++){
        deck.push(suits[i].slice(0,1)+cards[j]);
      }
    }
}

// Create shuffle card set using deck
function deck_shuffle(deck){
    for(let i=0; i<52;i++){
        let array_Num = Math.floor(Math.random()*deck.length);
        shuffle_deck.push(deck[array_Num]);
        deck.splice(array_Num,1);
    }
}

// Dealt card from shuffle card set
function dealt_card(total_card_count){
	let card= shuffle_deck[total_card_count];
    return card;
}

// Give corresponding values for each cards
function card_value(dealt_card){
	let letter = dealt_card.slice(1,dealt_card.length);
  switch(letter){
  	case "A":
    	return 1;
    case "2":
      return 2;
    case "3":
      return 3;
    case "4":
      return 4;
    case "5":
      return 5;
    case "6":
      return 6;
    case "7":
      return 7;
    case "8":
      return 8;
    case "9":
      return 9;
    case "10":
      return 10;
    case "J":
      return 10;
    case "Q":
      return 10;
    case "K":
      return 10;
      }
} 

//Store values for player score
function store_player_score(card_value){
  player_score = player_score+card_value;
  return player_score;
}

//Store values for computer score
function store_computer_score(card_value){
  computer_score = computer_score+card_value;
  return computer_score;
}

//Re-arrnge the final name
function final_name(dealt_card){
  let first_letter= dealt_card.slice(0,1);
  switch(first_letter){
    case "H":
  	  return "cards/"+dealt_card.slice(1,dealt_card.length)+ "_of_hearts.png";
    case "D":
  	  return "cards/"+dealt_card.slice(1,dealt_card.length)+ "_of_diamonds.png";
    case "C":
  	  return "cards/"+dealt_card.slice(1,dealt_card.length)+ "_of_clubs.png";
    case "S":
  	  return "cards/"+dealt_card.slice(1,dealt_card.length)+ "_of_spades.png";
 }
}

//Inject image
function image_inject(dealt_card,parentId,newChildClassName){
  let cardImg=document.createElement("img"); // create element tag to store an image in HTML file for player and computer cards
  cardImg.setAttribute("src",final_name(dealt_card)); // set source for "img" element for player and computer cards
  cardImg.setAttribute("class",newChildClassName); // set class for "img" element for player and computer cards
  document.getElementById(parentId).appendChild(cardImg); // insert the created elemet as a chlid into the parent element
}

//setting the image using img tag for current dealt card
function card_image_Set(dealt_card,imageId){
  document.getElementById(imageId).setAttribute("src",final_name(dealt_card));
}

//setting the text "img" tags
function label_Set(id,newText){
  document.getElementById(id).innerHTML=newText;
}


//MAIN PROGRAM

//link first page and intro page through "How to Play"button click
document.getElementById("intro_button1").addEventListener("click",enter_to_help_pg1);
function enter_to_help_pg1(){
  document.getElementById("intro_page").style.display = "block";
  document.getElementById("first_page").style.display = "none";
}

//link first page and play page through "Play Game" button click
document.getElementById("play_button1").addEventListener("click",enter_to_play_pg);
function enter_to_play_pg(){
  document.getElementById("play_page").style.display = "block";
  document.getElementById("first_page").style.display = "none";
}

//link intro page and play page through "Play Game" button click
document.getElementById("play_button2").addEventListener("click",enter_to_play_pg2);
function enter_to_play_pg2(){
  document.getElementById("play_page").style.display = "block";
  document.getElementById("intro_page").style.display = "none";
}

//link result page and play page through "Stop" button click
document.getElementById("stop_button").addEventListener("click",show_result);
function show_result(){
  document.getElementById("result_page").style.display = "block";
  document.getElementById("play_page").style.opacity = "0.25";
  document.getElementById("dealt_button").style.visibility="hidden";
  document.getElementById("stop_button").style.visibility="hidden";
}

//Player Turn
function player_game(){ 
  player_dealt_cards[player_dealt_card_count]=dealt_card(total_card_count); //  make player dealt card array using dealt cards
  player_score=store_player_score(card_value(player_dealt_cards[player_dealt_card_count])); //Get and store player score using card in the player dealt card array
  label_Set("player_value",player_score); // label the player score in front of th "player score" in the interface
  image_inject(player_dealt_cards[player_dealt_card_count],"left_box","suggest_img"); // inject the image from player dealt card array to the left box
  card_image_Set(player_dealt_cards[player_dealt_card_count],"current_card"); // set the current card (which is same for inject image) in to the middle box
  player_dealt_card_count++; // increse number of player dealt card count by 1
  total_card_count++; // with the player dealt card count increse the total card count
  if(player_score>21){
    label_Set("Result","You Busted");
    document.getElementById("result_page").style.display = "block"; //when result is taken it automatically show the result page(text)
    document.getElementById("play_page").style.opacity = "0.25";//setout the opacity of the display
    document.getElementById("dealt_button").style.visibility="hidden"; // hidden dealt button in order to block the dealt cards button because there is no chance to play further.
    document.getElementById("stop_button").style.visibility="hidden";// hidden dealt button in order to block the stop button because there is no chance to play further.
  }
// set the scroll option to aviod store the cards out of the box
if(player_dealt_card_count==7){
  document.getElementById("left_box").style.overflowY="scroll";
}
sound(); // insert sound function
}

//Computer Turn
function computer_game(){
  //computer should play the game until computer get busted (>21) and player_score<=computer_score
  while(computer_score<21 && player_score>computer_score){
    computer_dealt_cards[computer_dealt_card_count]=dealt_card(total_card_count); //  make computer dealt card array using dealt cards
    computer_score=store_computer_score(card_value(computer_dealt_cards[computer_dealt_card_count])); //Get and store computer score using card in the computer dealt card array
    label_Set("computer_value",computer_score); // label the computer score in fron of the "computer score" in the interface
    image_inject(computer_dealt_cards[computer_dealt_card_count],"right_box","suggest_img");// inject the image from computer dealt card array to the right box
    card_image_Set(computer_dealt_cards[computer_dealt_card_count],"current_card"); // set the curren card (which is same for inject image) in to the middle box
    computer_dealt_card_count++; // increse number of computer dealt card count by 1
    total_card_count++; // with the computer dealt card count increse the total card count
  }
  if(computer_score>21){
    label_Set("Result","Computer has busted and loses...then ....You Won!!");
    document.getElementById("result_page").style.display = "block";//when result is taken it automatically show the result page
    document.getElementById("play_page").style.opacity = "0.25";
    document.getElementById("dealt_button").style.visibility="hidden";// hidden dealt button in order to block to dealt cards button because there is no chance to play further.
    document.getElementById("stop_button").style.visibility="hidden";// hidden dealt button in order to block to stop button because there is no chance to play further.
  }else{
    label_Set("Result","Computer has not busted.....You Lost");
    document.getElementById("result_page").style.display = "block";
    document.getElementById("play_page").style.opacity = "0.25";
    document.getElementById("dealt_button").style.visibility="hidden";
    document.getElementById("stop_button").style.visibility="hidden"; 
  }

  // set the scroll option to aviod store the cards out of the box
  if(computer_dealt_card_count==7){
    document.getElementById("right_box").style.overflowY="scroll";
  }
  sound(); // insert sound function
}


//start to play game when click "Play Game" buttons in the First page and Intro Page. then function play_game is running
document.getElementById("play_button1").addEventListener("click",play_game);
document.getElementById("play_button2").addEventListener("click",play_game);

//Play game
function play_game(){
    card_deck(suits,cards); //Create deck using suits and cards
    deck_shuffle(deck); // shuffle the deck
    player_game(); // Get first card
    player_game(); // Get Second card
    document.getElementById("dealt_button").addEventListener("click",player_game); // when click the dealt button run above player_game function
    document.getElementById("stop_button").addEventListener("click",computer_game); // when click the stop button run above computer_game function
    }   

//restart the game when click the new game button
document.getElementById("new_game_button").addEventListener("click",new_game);

//start new game
function new_game(){
  deck=[]; // empty the deck
  shuffle_deck=[]; // empty the shuffle deck
  //remove the previous cards from the left box(cards indexes are start from 1)
  for(let i=1; i<player_dealt_card_count+1;i++){
    document.getElementById("left_box").children[1].remove();
  }
   //remove the previous cards from the right box(cards indexes are start from 1)
  for(let i=1; i<computer_dealt_card_count+1;i++){
    document.getElementById("right_box").children[1].remove();
  }
  player_dealt_cards=[]; // empty the player dealt card array
  computer_dealt_cards=[]; //empty the computer dealt card array
  player_score=0; //empty the player score
  computer_score=0; //empty the computer score
  total_card_count=0; //empty the total card count
  player_dealt_card_count=0; //empty the player dealt card count
  computer_dealt_card_count=0; //empty the computer dealt card array
  document.getElementById("player_value").textContent=0;
  document.getElementById("computer_value").textContent=0;
  play_game(); // run the play game function again
  //when strat the new game dealt button and stop button are again appear
  document.getElementById("dealt_button").style.visibility = "visible";
  document.getElementById("stop_button").style.visibility = "visible";
  document.getElementById("play_page").style.opacity = "1"; // reset the play page 
  document.getElementById("result_page").style.display = "none"; // remove the result page
}

//Apply sound for buton click//
document.getElementById("intro_button1").addEventListener("click",sound);
document.getElementById("intro_button2").addEventListener("click",sound);

function sound(){
  let audio = new Audio();
  audio.src = "mouseclick.mp3"; // source of the sound file
  audio.play();
}